if {![namespace exists ::IMEX]} { namespace eval ::IMEX {} }
set ::IMEX::dataVar [file dirname [file normalize [info script]]]
set ::IMEX::libVar ${::IMEX::dataVar}/libs

create_library_set -name tt_025C_1v80.extra_set\
   -timing\
    [list ${::IMEX::libVar}/mmmc/sky130_fd_sc_hd__tt_025C_1v80.lib\
    ${::IMEX::libVar}/mmmc/sky130_ef_io__gpiov2_pad_wrapped_tt_tt_025C_1v80_3v30.lib\
    ${::IMEX::libVar}/mmmc/fakeram_d64_w16.lib]
create_library_set -name ss_100C_1v60.setup_set\
   -timing\
    [list ${::IMEX::libVar}/mmmc/sky130_fd_sc_hd__ss_100C_1v60.lib\
    ${::IMEX::libVar}/mmmc/sky130_ef_io__gpiov2_pad_wrapped_ss_ss_100C_1v60_3v00.lib\
    ${::IMEX::libVar}/mmmc/fakeram_d64_w16.lib]
create_library_set -name ff_n40C_1v95.hold_set\
   -timing\
    [list ${::IMEX::libVar}/mmmc/sky130_fd_sc_hd__ff_n40C_1v95_ccsnoise.lib\
    ${::IMEX::libVar}/mmmc/sky130_ef_io__gpiov2_pad_wrapped_ff_ff_n40C_1v95_5v50.lib\
    ${::IMEX::libVar}/mmmc/fakeram_d64_w16.lib]
create_timing_condition -name ff_n40C_1v95.hold_cond\
   -library_sets [list ff_n40C_1v95.hold_set]
create_timing_condition -name tt_025C_1v80.extra_cond\
   -library_sets [list tt_025C_1v80.extra_set]
create_timing_condition -name ss_100C_1v60.setup_cond\
   -library_sets [list ss_100C_1v60.setup_set]
create_rc_corner -name tt_025C_1v80.extra_rc\
   -pre_route_res 1\
   -post_route_res 1\
   -pre_route_cap 1\
   -post_route_cap 1\
   -post_route_cross_cap 1\
   -pre_route_clock_res 0\
   -pre_route_clock_cap 0\
   -temperature 25
create_rc_corner -name ff_n40C_1v95.hold_rc\
   -pre_route_res 1\
   -post_route_res 1\
   -pre_route_cap 1\
   -post_route_cap 1\
   -post_route_cross_cap 1\
   -pre_route_clock_res 0\
   -pre_route_clock_cap 0\
   -temperature -40
create_rc_corner -name ss_100C_1v60.setup_rc\
   -pre_route_res 1\
   -post_route_res 1\
   -pre_route_cap 1\
   -post_route_cap 1\
   -post_route_cross_cap 1\
   -pre_route_clock_res 0\
   -pre_route_clock_cap 0\
   -temperature 100
create_delay_corner -name ss_100C_1v60.setup_delay\
   -timing_condition {ss_100C_1v60.setup_cond}\
   -rc_corner ss_100C_1v60.setup_rc
create_delay_corner -name tt_025C_1v80.extra_delay\
   -timing_condition {tt_025C_1v80.extra_cond}\
   -rc_corner tt_025C_1v80.extra_rc
create_delay_corner -name ff_n40C_1v95.hold_delay\
   -timing_condition {ff_n40C_1v95.hold_cond}\
   -rc_corner ff_n40C_1v95.hold_rc
create_constraint_mode -name my_constraint_mode\
   -sdc_files\
    [list /dev/null]
create_analysis_view -name tt_025C_1v80.extra_view -constraint_mode my_constraint_mode -delay_corner tt_025C_1v80.extra_delay
create_analysis_view -name ss_100C_1v60.setup_view -constraint_mode my_constraint_mode -delay_corner ss_100C_1v60.setup_delay
create_analysis_view -name ff_n40C_1v95.hold_view -constraint_mode my_constraint_mode -delay_corner ff_n40C_1v95.hold_delay
set_analysis_view -setup [list ss_100C_1v60.setup_view] -hold [list ff_n40C_1v95.hold_view tt_025C_1v80.extra_view]
